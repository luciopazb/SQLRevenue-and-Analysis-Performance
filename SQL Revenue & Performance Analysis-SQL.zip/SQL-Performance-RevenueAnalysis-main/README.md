# SQL-Analysis
SQL querys realizados para analizar la data de una compañia
